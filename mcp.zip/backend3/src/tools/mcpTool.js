import { mcp } from '@llamaindex/tools';

/**
 * Creates an MCP client that connects to our custom MCP server
 * This tool allows the agent to use the file listing capabilities
 * provided by our MCP server
 */
const createMcpClient = async () => {
  try {
    // Initialize MCP client to connect to our custom MCP server
    const mcpClient = mcp({
      url: (process.env.MCP_SERVER_URL || 'http://localhost:4000') + '/mcp',
      verbose: true
    });
    
    // Get tools from the MCP server
    const mcpTools = await mcpClient.tools();
    console.log('Successfully connected to MCP server and loaded tools');
    return mcpTools;
  } catch (error) {
    console.error('Error initializing MCP client:', error);
    return [];
  }
};

export default createMcpClient;