import { tool } from 'llamaindex';
import { z } from 'zod';

// Multiplication tool
const multiplyTool = tool({
  name: "multiply",
  description: "Multiplies two numbers",
  parameters: z.object({
    a: z.number(),
    b: z.number(),
  }),
  execute: ({ a, b }) => a * b,
});

export default multiplyTool;