import { tool } from 'llamaindex';
import { z } from 'zod';

// Calculation tool
const calculateTool = tool({
  name: "calculate",
  description: "calculate the result from two numbers given",
  parameters: z.object({
    a: z.number(),
    b: z.number(),
  }),
  execute: ({ a, b }) => a * b,
});

export default calculateTool;