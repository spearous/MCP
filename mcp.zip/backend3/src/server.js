import express from 'express';
import { agent } from '@llamaindex/workflow';
import { ollama } from '@llamaindex/ollama';
import cors from 'cors';
import dotenv from 'dotenv';
import { calculateTool, multiplyTool, createMcpClient } from './tools/index.js';

// Load environment variables
dotenv.config();

const app = express();

// Enable CORS middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000', // Frontend application address
  methods: ['GET', 'POST'],
  credentials: true
}));

app.use(express.json());

// Add root route response for connection check
app.get('/', (req, res) => {
  res.json({ message: 'Backend2 API is running' });
});

// Initialize agent once at startup
let myAgent;

// Function to initialize or reinitialize the agent
async function initializeAgent() {
  // Tools are imported from tools directory
  
  try {
    // Get MCP tools from our custom MCP server
    const mcpTools = await createMcpClient();
    
    // Create the agent - using a model that supports tools
    myAgent = agent({
      tools: [calculateTool, multiplyTool, ...mcpTools],
      llm: ollama({ 
        model: process.env.MODEL_NAME || "llama3.2:1b",
        temperature: parseFloat(process.env.MODEL_TEMPERATURE || 0.7)
      }), // Using a model that supports tools, like llama3
    });
    console.log(`Agent initialized with model: ${process.env.MODEL_NAME}, temperature: ${process.env.MODEL_TEMPERATURE}`);
    console.log(`MCP tools loaded: ${mcpTools.length > 0 ? 'Yes' : 'No'}`);
    return true;
  } catch (error) {
    console.error('Unable to initialize agent with tools, trying without tools:', error);
    // Fallback: initialize without tools
    try {
      myAgent = agent({
        llm: ollama({ 
          model: process.env.MODEL_NAME || "llama3.2:1b",
          temperature: parseFloat(process.env.MODEL_TEMPERATURE || 0.7)
        }),
      });
      console.log(`Agent initialized without tools. Model: ${process.env.MODEL_NAME}, temperature: ${process.env.MODEL_TEMPERATURE}`);
      return true;
    } catch (err) {
      console.error('Failed to initialize agent:', err);
      return false;
    }
  }
}

// Initialize the agent on startup
(async () => {
  await initializeAgent();
  console.log('Agent initialization completed');
})().catch(err => {
  console.error('Error during agent initialization:', err);
});

app.post('/api/chat', async (req, res) => {
  try {
    // Check if agent is initialized
    if (!myAgent) {
      console.log('Agent not initialized yet, returning fallback response');
      return res.json({ response: 'Server is initializing, please try again later.' });
    }
    
    const { message, model, temperature } = req.body;
    
    // Override environment variables if provided in the request
    let modelChanged = false;
    
    if (model && model !== process.env.MODEL_NAME) {
      process.env.MODEL_NAME = model;
      modelChanged = true;
    }
    
    if (temperature && parseFloat(temperature) !== parseFloat(process.env.MODEL_TEMPERATURE)) {
      process.env.MODEL_TEMPERATURE = temperature;
      modelChanged = true;
    }
    
    // Reinitialize agent if model parameters changed
    if (modelChanged) {
      console.log('Model parameters changed, reinitializing agent...');
      initializeAgent();
    }
    
    try {
      // Try to process message with agent
      const result = await myAgent.run(message);
      
      // Check if response is an object, if so beautify JSON format
      let responseData = result.data;
      if (typeof responseData === 'object') {
        // Use JSON.stringify to beautify format with 2 space indentation
        responseData = JSON.stringify(responseData, null, 2);
      }
      
      res.json({ response: responseData });
    } catch (agentError) {
      console.error('Agent error:', agentError);
      // If agent processing fails, return a simple response
      res.json({ 
        response: `Received your message: "${message}". Sorry, the AI assistant cannot process complex requests at this time.` 
      });
    }
  } catch (error) {
    console.error('Chat error:', error);
    // Ensure we always return 200 status code and valid JSON response
    res.json({ 
      response: 'Sorry, the server encountered a problem. Please try again later.',
      error: error.message || 'Unknown error'
    });
  }
});

// Initialize and start server
const agentInitialized = initializeAgent();

if (agentInitialized) {
  console.log('Agent initialized successfully');
} else {
  console.error('Failed to initialize agent');
  // Agent functionality will be unavailable
}

// Start server
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';
app.listen(PORT, HOST, () => {
  console.log(`Server running on ${HOST}:${PORT}`);
});