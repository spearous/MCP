import React, { useEffect } from 'react';
import './MessageList.css';

// Format JSON and make keys bold
const formatJSON = (jsonString) => {
  try {
    // Replace key names in JSON string, add span tags with bold style
    return jsonString.replace(/"(\w+)"\s*:/g, '"<span class="json-key">$1</span>":')
  } catch (error) {
    console.error('JSON formatting error:', error);
    return jsonString;
  }
};

function MessageList({ messages, currentUser, messagesEndRef }) {
  // Format timestamp
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Ensure message container scrolls to bottom
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'auto', block: 'end' });
    }
  }, [messages, messagesEndRef]);

  return (
    <div className="message-list">
      <div style={{ flexGrow: 1 }}></div>
      {messages.length === 0 ? (
        <div className="no-messages">No messages yet, start chatting!</div>
      ) : (
        messages.map((message) => (
          <div 
            key={message.id} 
            className={`message ${message.user === currentUser ? 'own-message' : ''}`}
          >
            <div className="message-header">
              <span className="message-user">{message.user}</span>
              <span className="message-time">{formatTimestamp(message.timestamp)}</span>
            </div>
            <div className="message-text">
              {message.text && message.text.startsWith('{') && message.text.includes('\n') ? 
                <pre 
                  style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
                  dangerouslySetInnerHTML={{ __html: formatJSON(message.text) }}
                /> : 
                message.text
              }
            </div>
          </div>
        ))
      )}
      <div ref={messagesEndRef} style={{ float: 'left', clear: 'both', width: '100%' }} />
    </div>
  );
}

export default MessageList;