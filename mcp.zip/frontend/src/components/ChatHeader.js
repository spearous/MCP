import React from 'react';
import './ChatHeader.css';

function ChatHeader({ username, isConnected, onChangeUser }) {
  return (
    <div className="chat-header">
      <div className="header-title">
        <h2>Chat Room</h2>
        <div className="connection-status">
          <span className={`status-indicator ${isConnected ? 'connected' : 'disconnected'}`}></span>
          <span className="status-text">{isConnected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>
      <div className="user-info">
        <span>Current User: <strong>{username}</strong></span>
        <button onClick={onChangeUser} className="change-user-btn">Change User</button>
      </div>
    </div>
  );
}

export default ChatHeader;