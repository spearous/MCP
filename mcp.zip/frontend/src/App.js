import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import axios from 'axios';
import './App.css';
import ChatHeader from './components/ChatHeader';
import MessageList from './components/MessageList';
import MessageInput from './components/MessageInput';

// Backend API URL - ensure it matches the backend server address
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Create socket connection - only needed when using backend
// If using backend2, socket connection is not needed
let socket;
try {
  socket = io(API_URL);
} catch (error) {
  console.error('Socket.io connection failed:', error);
}

function App() {
  const [messages, setMessages] = useState([]);
  const [user, setUser] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef(null);

  // Handle username setting
  const handleSetUser = (name) => {
    setUser(name);
    localStorage.setItem('chatUsername', name);
  };

  // Send message
  const sendMessage = async (text) => {
    if (!text.trim() || !user) return;
    
    const message = {
      text,
      user
    };
    
    try {
      // Check if socket is available, if so use Socket.io to send message
      if (socket && socket.connected) {
        socket.emit('send_message', message);
      } else {
        // Otherwise use REST API to send message
        const response = await axios.post(`${API_URL}/api/chat`, { message: text });
        
        // Create a new message object
        const responseText = response.data.response;
        const newMessage = {
          id: Date.now(),
          text: typeof responseText === 'object' ? JSON.stringify(responseText) : (responseText || response.data.error || 'No response'),
          user: 'AI Assistant',
          timestamp: new Date().toISOString()
        };
        
        // Add user's message and AI's response
        setMessages(prev => [...prev, 
          {
            id: Date.now() - 1,
            text: text,
            user: user,
            timestamp: new Date().toISOString()
          },
          newMessage
        ]);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      // Add error notification to message list
      setMessages(prev => [...prev, 
        {
          id: Date.now() - 1,
          text: text,
          user: user,
          timestamp: new Date().toISOString()
        },
        {
          id: Date.now(),
          text: `Send failed: ${error.message || 'Connection error'}`,
          user: 'System',
          timestamp: new Date().toISOString(),
          isError: true
        }
      ]);
    }
  };

  // Scroll to latest message
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      // Use auto instead of smooth to ensure immediate scrolling
      messagesEndRef.current.scrollIntoView({ behavior: 'auto', block: 'end' });
      // Add extra forced scrolling to ensure correct scrolling in certain cases
      setTimeout(() => {
        window.scrollTo(0, document.body.scrollHeight);
        messagesEndRef.current?.scrollIntoView({ behavior: 'auto', block: 'end' });
      }, 100);
    }
  };

  // Check API connection status
  const checkApiConnection = async () => {
    try {
      await axios.get(`${API_URL}`);
      setIsConnected(true);
      return true;
    } catch (error) {
      console.log('API connection check failed, trying to connect to /api/chat');
      try {
        // Try sending an empty message to check connection
        await axios.post(`${API_URL}/api/chat`, { message: '' });
        setIsConnected(true);
        return true;
      } catch (err) {
        console.error('API connection failed:', err);
        setIsConnected(false);
        return false;
      }
    }
  };

  // Initialize connection and event listeners
  useEffect(() => {
    // Check username in local storage
    const savedUsername = localStorage.getItem('chatUsername');
    if (savedUsername) {
      setUser(savedUsername);
    }
    
    // Check API connection
    checkApiConnection();
    
    // Periodically check connection status
    const connectionCheckInterval = setInterval(checkApiConnection, 10000);


    // If socket exists, set up Socket.io event listeners
    if (socket) {
      // Connect event
      socket.on('connect', () => {
        console.log('Connected to Socket.io server');
        setIsConnected(true);
      });

      // Disconnect event
      socket.on('disconnect', () => {
        console.log('Disconnected from Socket.io server');
        // Don't set to false immediately, try checking connection via REST API
        checkApiConnection();
      });

      // Receive message event
      socket.on('receive_message', (message) => {
        setMessages(prev => [...prev, message]);
      });

      // Receive message history event
      socket.on('message_history', (history) => {
        setMessages(history);
      });
    }

    // Cleanup when component unmounts
    return () => {
      if (socket) {
        socket.off('connect');
        socket.off('disconnect');
        socket.off('receive_message');
        socket.off('message_history');
      }
      clearInterval(connectionCheckInterval);
    };
  }, []);

  // Scroll to bottom when message list updates
  useEffect(() => {
    // Scroll immediately once
    scrollToBottom();
    // Scroll again with delay to ensure scrolling after DOM is fully updated
    const scrollTimer = setTimeout(() => {
      scrollToBottom();
    }, 200);
    
    return () => clearTimeout(scrollTimer);
  }, [messages]);

  // If username is not set, show username input interface
  if (!user) {
    return (
      <div className="app">
        <div className="username-container">
          <h2>Please enter your username</h2>
          <form onSubmit={(e) => {
            e.preventDefault();
            const input = e.target.elements.username;
            handleSetUser(input.value);
          }}>
            <input 
              type="text" 
              name="username" 
              placeholder="Enter username..."
              required
            />
            <button type="submit">Enter Chat</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <div className="chat-container">
        <ChatHeader 
          username={user} 
          isConnected={isConnected} 
          onChangeUser={() => setUser('')}
        />
        
        <MessageList 
          messages={messages} 
          currentUser={user} 
          messagesEndRef={messagesEndRef}
        />
        
        <MessageInput 
          onSendMessage={sendMessage} 
          disabled={!isConnected}
        />
      </div>
    </div>
  );
}

export default App;