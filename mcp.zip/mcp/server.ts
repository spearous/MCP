import express from 'express';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

// Load environment variables from param.env
dotenv.config({ path: path.resolve(__dirname, 'param.env') });

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware to parse JSON requests
app.use(express.json());

// Define the MCP tool schema
const listFilesToolSchema = {
  name: 'list_files',
  description: 'Lists files in a specified directory',
  input_schema: {
    type: 'object',
    properties: {
      directory: {
        type: 'string',
        description: 'The directory path to list files from. If not provided, lists files from project root.'
      }
    }
  },
  output_schema: {
    type: 'object',
    properties: {
      files: {
        type: 'array',
        items: {
          type: 'string'
        },
        description: 'List of files in the directory'
      }
    }
  }
};

// MCP endpoint for tool discovery
app.all('/mcp', (req, res) => {
  res.json({
    jsonrpc: '2.0',
    id: 'file-system-tools',
    result: {
      tools: [listFilesToolSchema]
    }
  });
});

// MCP endpoint to list files in a directory
app.post('/mcp/list_files', (req, res) => {
  try {
    // Get directory from request or use project root
    const directory = req.body.directory || path.resolve(__dirname, '..');
    
    // Resolve the directory path
    const resolvedPath = path.resolve(directory);
    
    // Check if the directory exists
    if (!fs.existsSync(resolvedPath)) {
      return res.status(404).json({ error: 'Directory not found.' });
    }
    
    // Check if the path is a directory
    if (!fs.lstatSync(resolvedPath).isDirectory()) {
      return res.status(400).json({ error: 'Provided path is not a directory.' });
    }
    
    // Read the directory and list files
    const files = fs.readdirSync(resolvedPath).map(file => {
      const filePath = path.join(resolvedPath, file);
      const isDirectory = fs.lstatSync(filePath).isDirectory();
      return isDirectory ? `${file}/` : file;
    });
    
    res.json({ files });
  } catch (error) {
    console.error('Error listing files:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`MCP server is running on http://localhost:${PORT}`);
  console.log(`Tool discovery endpoint: http://localhost:${PORT}/mcp`);
  console.log(`List files endpoint: http://localhost:${PORT}/mcp/list_files`);
});