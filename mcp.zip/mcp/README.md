# MCP Server for File Listing

This is a simple Model Context Protocol (MCP) server that provides a tool for listing files in a directory. By default, it lists files in the project root directory.

## What is MCP?

Model Context Protocol (MCP) allows AI assistants to use external tools when they need specific capabilities. This MCP server acts as an interface between AI models and the file system, providing a tool to list files in a directory.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Start the server:
   ```
   npm start
   ```

## Endpoints

- **Tool Discovery**: `GET /mcp`
  Returns the available tools and their schemas.

- **List Files**: `POST /mcp/list_files`
  Lists files in a directory.

  Request body:
  ```json
  {
    "directory": "path/to/directory" // Optional, defaults to project root
  }
  ```

  Response:
  ```json
  {
    "files": ["file1.txt", "file2.js", "directory1/"]
  }
  ```

## Environment Variables

The server can be configured using the following environment variables in the `param.env` file:

- `PORT`: The port on which the server runs (default: 4000)
- `HOST`: The host on which the server runs (default: localhost)